# Force New Tab 2.0.2 — test build

Improved middle-click support for blank areas within cards.

- Matching heading and thumbnail links can identify a card's destination when you middle-click its surrounding whitespace.
- Clear matches open directly without activating the original card.
- The new rule excludes nested action controls, unrelated cards and ambiguous destinations.
- Documentation and testing guidance describe shared navigation behaviors across websites.
- The separate testing package restores optional local click reports. Its navigation modules are identical to the clean shipping candidate.
- Minor housekeeping removes an unloaded stub and an unused function parameter, and reads status build versions from the manifest.

## Previous update: 2.0.1

- Broader automatic destination finding for links, cards, images and JavaScript-driven buttons.
- Difficult controls can use a background copy after direct methods are exhausted. Copied pages wait for the matching control to settle before a single press.
- Updated purple ON / grey OFF fist artwork and clearer reporting links.
- The public build has no click recorder or separate feature switches.

## Installation

Requires **Firefox 147 or newer**. This local test build is **unsigned** and has not been published. It does not automatically update installed add-ons.

For a temporary test, use the prepared `dist/testing/manifest.json` through **about:debugging → This Firefox → Load Temporary Add-on**. If starting from the source ZIP, run `node tools/build.cjs` first. Open the testing add-on's Preferences to use the recorder. See [START-HERE.md](START-HERE.md). Temporary installation ends when Firefox restarts. For the currently Mozilla-distributed version, use [Firefox Add-ons](https://addons.mozilla.org/en-US/firefox/addon/force-new-tab/).

## Expectations

Known destinations open promptly; the copied-page fallback can take up to 15 seconds. A website can still refuse an automatic click, fail to reproduce a popup, or change the original page during the final fallback. Individual successful site tests do not guarantee every control works.

All 15 public automated suites pass. These simulate browser behavior. Additional browser checks cover one live card layout; Firefox confirmation remains pending. See [verification details](TEST-RESULTS-2.0.2.md).
